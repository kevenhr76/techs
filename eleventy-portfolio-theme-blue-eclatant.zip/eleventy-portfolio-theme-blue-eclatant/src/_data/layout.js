// Set default layout
// https://github.com/11ty/eleventy/issues/380#issuecomment-568033456

module.exports = 'layouts/page.ejs';
